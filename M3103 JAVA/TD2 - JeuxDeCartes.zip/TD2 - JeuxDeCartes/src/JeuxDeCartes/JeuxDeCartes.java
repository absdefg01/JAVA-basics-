package JeuxDeCartes;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class JeuxDeCartes {
	private Carte[] paquets;
	private int nbCartesRestantes;
	
	/**
	 * constructeur
	 * @param unJeuxDeCarte
	 */
	public JeuxDeCartes(){
		this.paquets = new Carte[Valeur.values().length*Couleur.values().length];
		int ii = 0;
		for(Valeur v : Valeur.values()){
			for(Couleur c : Couleur.values()){
				this.paquets[ii] = new Carte(v,c);
				ii++;
				System.out.println(this.paquets[ii]);
			}
		}
		this.nbCartesRestantes = this.paquets.length;
	}

	public void classer(){
		//implemetation du tri � billes
		boolean echange;
		do{
			echange = false;
			for (int i=0; i<this.nbCartesRestantes; i++){
				if( (this.paquets[i].getCouleur().ordinal()>this.paquets[i+1].getCouleur().ordinal())||
						(this.paquets[i].getCouleur().ordinal()==this.paquets[i+1].getCouleur().ordinal()&&(this.paquets[i].getValeur().ordinal()>this.paquets[i+1].getValeur().ordinal())) ){
					Carte c = this.paquets[i];
					this.paquets[i]=this.paquets[i+1];
					this.paquets[i+1]=c;
					echange = true;
				}
			}
		}while(echange);
	}
	
	public void m�langer(){
		List<Integer> indicePossible = new LinkedList<Integer>();
		//Initialisation des indices possibles
		for(int i = 0; i<this.nbCartesRestantes; i++){
			indicePossible.add(i);	
		}
		//cr�ation du nouveau tableau
		Carte[] nouveau = new Carte[this.paquets.length];
		Random rand = new Random();
		int indice;
		for(int i=0; i< this.nbCartesRestantes; i++){
			indice = rand.nextInt(indicePossible.size());
			nouveau[i] = this.paquets[indicePossible.get(indice)];
			indicePossible.remove(indice);
		}
		this.paquets=nouveau;
	}
	
	private void rotationsVersGauche(Carte[] tab){
		Carte tmp = tab[0];
		for (int i = 0; i<this.nbCartesRestantes-1; i++){
			tab[i]=tab[i+1];
		}
		tab[this.nbCartesRestantes-1]=tmp;
	}
	
	public String retourne(){
		this.rotationsVersGauche(this.paquets);
		return this.paquets[this.nbCartesRestantes-1].toString();
	}
	
	public Carte distribue() throws PaquetVide{
		if (this.nbCartesRestantes == 0){
			throw new PaquetVide();
		}
		Carte tmp = this.paquets[0];
		this.rotationsVersGauche(this.paquets);
		this.nbCartesRestantes--;
		return tmp;
	}
	

}
