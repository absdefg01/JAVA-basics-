package JeuxDeCartes;

public class PaquetVide extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaquetVide(){
		super("Paquet de carte vide ! ");
	}

}
