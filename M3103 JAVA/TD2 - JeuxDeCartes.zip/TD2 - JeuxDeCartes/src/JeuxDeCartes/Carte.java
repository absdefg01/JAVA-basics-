package JeuxDeCartes;

enum Valeur {Sept, Huit, Neuf, Dix, Valet, Dame, Roi, As}
enum Couleur {Pique, Coeur, Carreau, Tretle}

public class Carte {
	private Valeur valeur;
	private Couleur couleur;
	
	/**
	 * constructeur
	 */
	public Carte(Valeur valeur, Couleur couleur){
		this.valeur = valeur;
		this.couleur = couleur;
	}
	
	/**
	 * accesseur
	 * @return valeur des cartes
	 */
	public Valeur getValeur(){
		return this.valeur;
	}
	/**
	 * accesseur
	 * @return couleur des cartes
	 */
	public Couleur getCouleur(){
		return this.couleur;
	}

	public String toString() {
		return this.valeur + "De" + this.couleur;
	}

}
