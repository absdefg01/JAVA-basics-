


public class ListeVide extends Exception{
	
	
	public ListeVide(){
		super("La liste est vide");
	}
	

}
