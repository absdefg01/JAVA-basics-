
public class CompteEpargneLogement extends CompteBancaire{

	public CompteEpargneLogement(String l, Devise d) {
		super(l, d);
	}
	

}
