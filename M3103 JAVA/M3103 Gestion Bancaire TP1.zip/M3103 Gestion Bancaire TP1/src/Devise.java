
public enum Devise {Dollar, Euro};
