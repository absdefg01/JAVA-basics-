package JeuxDeCartes;

public class PaquetVide extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8285062940078232953L;

	public PaquetVide(){
		super("Paquet est vide");
	}

}
