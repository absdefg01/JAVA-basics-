package Journalisation;

import java.util.HashMap;
import java.util.Map;

public class Multiton {
	private static final Map<Object, Multiton> instances = new HashMap<Object, Multiton>();
	 
    private Multiton() {
        // no explicit implementation
    }
 
    public static synchronized Multiton getInstance(String key) {
 
        // Our "per key" singleton
        Multiton instance = instances.get(key);
 
        if (instance == null) {
            // Lazily create instance
            instance = new Multiton();
 
            // Add it to map   
            instances.put(key, instance);
        }
 
        return instance;
    }

}
