package Journalisation;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Journal {

	private StringBuffer log;
	private static Journal instance;
	private static Journal instance2;
	private static final Map<String, Journal> instances = new HashMap<String, Journal>();
	
	public static synchronized Journal getInstance(String key)
	{
		Journal instance = instances.get(key);
		
		if (instance == null)
			instance = new Journal();
			instances.put(key, instance);s

		return instance;
	}
	
	public static synchronized Journal getInstance2()
	{
		if (instance2 == null)
			instance2 = new Journal();

		return instance2;
	}

	public Journal() {
		this.log = new StringBuffer();
	}

	public void ajouterLog(String log) {
		Date d = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH'h'mm'm'ss's'SSS");
		this.log.append("[" + dateFormat.format(d) + "] " + log + "\n");
	}

	@Override
	public String toString() {
		return this.log.toString();
	}	
}
