public class Poids extends Produit {

	private float poids;

	public void setPoids(float poids) {
		this.poids = poids;
	}

	public float getPoids() {
		return poids;
	}
	

}
