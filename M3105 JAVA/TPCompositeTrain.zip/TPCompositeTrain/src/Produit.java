public abstract class Produit {

	private float prix;
	private String descriptif;
	private String codeBarre;

	public float getPrix(){
		return this.prix;
	}

	public String getDescriptif() {
		return descriptif;
	}

	public String getCodeBarre() {
		return codeBarre;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}

	public void setDescriptif(String descriptif) {
		this.descriptif = descriptif;
	}

	public void setCodeBarre(String codeBarre) {
		this.codeBarre = codeBarre;
	}

}
