
public class Barre extends Produit {

	private float longueur;

	public void setLongueur(float longueur) {
		this.longueur = longueur;
	}

	public float getLongueur() {
		return longueur;
	}
	


}
