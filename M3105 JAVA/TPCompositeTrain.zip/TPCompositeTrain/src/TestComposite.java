
public class TestComposite {

	public static void main(String[] args) {
		Barre maBarre = new Barre();
			maBarre.setPrix(25f);
			maBarre.setDescriptif("Barre d'halt�rophilie");
			maBarre.setCodeBarre("BA0001");
			maBarre.setLongueur(150f);
		Poids leger = new Poids();
			leger.setPrix(15f);
			leger.setDescriptif("Poids d'halt�re");
			leger.setCodeBarre("PA0001");
			leger.setPoids(0.5f);
		Poids moyen = new Poids();
			moyen.setPrix(17f);
			moyen.setDescriptif("Poids d'halt�re");
			moyen.setCodeBarre("PA0002");
			moyen.setPoids(1f);
		Poids lourd = new Poids();
			lourd.setPrix(19f);
			lourd.setDescriptif("Poids d'halt�re");
			lourd.setCodeBarre("PA0003");
			lourd.setPoids(1.5f);
		ProduitComposite haltere = new ProduitComposite();
			haltere.setDescriptif("Je suis un pack d'halt�res");
			haltere.setCodeBarre("HA0001");
			haltere.add(maBarre);
			haltere.add(leger);
			haltere.add(moyen);
			haltere.add(lourd);
			
			System.out.println(maBarre.getPrix());
			System.out.println(leger.getPrix());
			System.out.println(moyen.getPrix());
			System.out.println(lourd.getPrix());
			System.out.println(haltere.getPrix());
			
			System.out.println(maBarre.getCodeBarre());
			System.out.println(leger.getCodeBarre());
			System.out.println(moyen.getCodeBarre());
			System.out.println(lourd.getCodeBarre());
			System.out.println(haltere.getCodeBarre());
			
			System.out.println(haltere.getDescriptif());
	}

}
