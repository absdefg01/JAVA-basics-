import java.util.ArrayList;
import java.util.List;

public class ProduitComposite extends Produit {

	List<Produit> produits;

	public ProduitComposite() {
		this.produits = new ArrayList<>();
	}

	public void add(Produit p) {
		this.produits.add(p);
	}

	public void remove(Produit p) {
		this.produits.remove(p);
	}

	public List<Produit> getProduits() {
		return produits;
	}
	
	
	
	public String getDescriptif(){
		String s = super.getDescriptif()+"\n";
		for(Produit p : this.produits){
			s+=p.getDescriptif()+"\n";
		}
		return s;
	}

	public float getPrix() {
		float f = 0f;
		for (Produit p : this.produits) {
			f += p.getPrix();
		}
		f *= 0.9f;
		return f;
	}

}
