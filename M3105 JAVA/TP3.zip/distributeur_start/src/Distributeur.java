

import java.util.LinkedList;
import java.util.List;

public class Distributeur {
	
	private EtatDistributeur etat;
	
	public Distributeur(int nb50, int nb20, int nb10) {
		this.etat = new EtatDistributeur();
		recharger(nb50, nb20, nb10);
	}

	public void recharger(int nb50, int nb20, int nb10) {
		this.etat.setNb50Disponible(nb50);
		this.etat.setNb20Disponible(nb20);
		this.etat.setNb10Disponible(nb10);
	}
	
	public List<Couple> donnerBillets(int montant){
		List<Couple> proposition = new LinkedList<Couple>();
		WrapperMontant m= new WrapperMontant(montant);
		CalculatorBillets50 cb50 = new CalculatorBillets50();
		CalculatorBillets20 cb20 = new CalculatorBillets20();
		CalculatorBillets10 cb10 = new CalculatorBillets10();
		cb50.donnerBillets50(m,proposition,this.etat);
		cb20.donnerBillets20(m,proposition,this.etat);
		cb10.donnerBillets10(m,proposition,this.etat);
		return proposition;	
	}
	
	public List<Couple> donnerBillets50(WrapperMontant montant,List<Couple> proposition) {
		// Gestion des billets de 50 �
		int u = montant.getMontant();
		if (u > 50) {
			int nBillets50 = Math.min((int)Math.ceil(u/2/50), this.etat.getNb50Disponible());
			u -= nBillets50*50;
			this.etat.setNb50Disponible(this.etat.getNb50Disponible() - nBillets50);
			if (nBillets50 > 0) {
				proposition.add(new Couple(50,nBillets50));
			}
		}
		return proposition;
	}
	
	public List<Couple> donnerBillets20(WrapperMontant montant,List<Couple> proposition) {  
		//Gestion des billets de 20 �
		int u = montant.getMontant();
		if (u > 20) {
			int nBillets20 = 0;
			if (u % 20 == 0) {
				nBillets20 = u / 20 -1;
			}
			else {
				nBillets20 = u / 20;
			}
			nBillets20 = Math.min(nBillets20, this.etat.getNb20Disponible());
			u -= nBillets20*20;
			this.etat.setNb20Disponible(this.etat.getNb20Disponible() - nBillets20);
			proposition.add(new Couple(20,nBillets20));
		}
		return proposition;
	}
	
        
	public List<Couple> donnerBillets10(WrapperMontant montant,List<Couple> proposition) {
		//Gestion des billets de 10 �
		int u = montant.getMontant();
		if (u > 0) {
			int nBillets10 = Math.min(u/10, this.etat.getNb10Disponible());
			u -= nBillets10*10;
			this.etat.setNb10Disponible(this.etat.getNb10Disponible() - nBillets10);
			proposition.add(new Couple(10,nBillets10));
		}
		
		return proposition;
    }

	public String toStringProposition(List<Couple> proposition, int montant) {
		StringBuffer res = new StringBuffer();
		res.append("Montant � d�biter : " + montant + "� \n");
		for (Couple c : proposition) {
			res.append(c.toString() + '\n');
		}
		res.append("Montant restant d� : " + this.montantRestantD�(proposition, montant));
		return res.toString();
	}
	
	public int montantRestantD�(List<Couple> proposition, int montant) {
		int montantRestantD� = montant;
		for (Couple c : proposition) {
			montantRestantD� -= c.getValeurBillet() * c.getNombreBilletsD�livr�s();
		}
		return montantRestantD�;
	}
}
