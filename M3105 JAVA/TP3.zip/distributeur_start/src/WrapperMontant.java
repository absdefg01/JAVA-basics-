
public class WrapperMontant {
	private int montant;
	
	public WrapperMontant(int m){
		this.montant = m;
	}
	
	public int getMontant(){
		return this.montant;
	}
	
	public void setMontant(int m){
		this.montant = m;
	}

	@Override
	public String toString() {
		return "WrapperMontant [montant=" + montant + "]";
	}
	
	
	
	
	

}
