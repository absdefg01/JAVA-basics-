import java.util.List;


public class CalculatorBillets50 {
	
	public List<Couple> donnerBillets50(WrapperMontant montant,List<Couple> proposition,EtatDistributeur etat) {
		// Gestion des billets de 50 �
		int u = montant.getMontant();
		if (u > 50) {
			int nBillets50 = Math.min((int)Math.ceil(u/2/50), etat.getNb50Disponible());
			u -= nBillets50*50;
			etat.setNb50Disponible(etat.getNb50Disponible() - nBillets50);
			if (nBillets50 > 0) {
				proposition.add(new Couple(50,nBillets50));
			}
		}
		return proposition;
	}

}
