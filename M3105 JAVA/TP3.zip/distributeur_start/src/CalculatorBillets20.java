import java.util.List;


public class CalculatorBillets20 {
	
	public List<Couple> donnerBillets20(WrapperMontant montant,List<Couple> proposition,EtatDistributeur etat) {  
		//Gestion des billets de 20 �
		int u = montant.getMontant();
		if (u > 20) {
			int nBillets20 = 0;
			if (u % 20 == 0) {
				nBillets20 = u / 20 -1;
			}
			else {
				nBillets20 = u / 20;
			}
			nBillets20 = Math.min(nBillets20, etat.getNb20Disponible());
			u -= nBillets20*20;
			etat.setNb20Disponible(etat.getNb20Disponible() - nBillets20);
			proposition.add(new Couple(20,nBillets20));
		}
		return proposition;
	}

}
