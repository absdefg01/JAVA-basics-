import java.util.List;


public class CalculatorBillets10 {
	
	
	public List<Couple> donnerBillets10(WrapperMontant montant,List<Couple> proposition,EtatDistributeur etat) {
		//Gestion des billets de 10 �
		int u = montant.getMontant();
		if (u > 0) {
			int nBillets10 = Math.min(u/10, etat.getNb10Disponible());
			u -= nBillets10*10;
			etat.setNb10Disponible(etat.getNb10Disponible() - nBillets10);
			proposition.add(new Couple(10,nBillets10));
		}
		
		return proposition;
    }


}
