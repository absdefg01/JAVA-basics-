package atm;

public class WrapperMontant {
	private int montant;

	public WrapperMontant(int montant) {
		this.montant = montant;
	}

	public int getMontant() {
		return montant;
	}

	public void setMontant(int montant) {
		this.montant = montant;
	}	
}