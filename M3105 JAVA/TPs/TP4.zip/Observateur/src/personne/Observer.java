package personne;

public interface Observer {
	
	public void update(Subject s);
	
}
