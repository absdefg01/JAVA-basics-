
public class Immeuble extends ObjetGraphique implements Cloneable {
private String couleur;
private int nbEtages;
private int hauteurEtage;
	public Immeuble(double x, double y, String c, int nE, int hE) {
		super(x, y);
		this.couleur=c;
		this.hauteurEtage=hE;
		this.nbEtages=nE;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public void setNbEtages(int nbEtages) {
		this.nbEtages = nbEtages;
	}
	public void setHauteurEtage(int hauteurEtage) {
		this.hauteurEtage = hauteurEtage;
	}
	@Override
	public String toString() {
		return "Immeuble [couleur=" + couleur + ", nbEtages=" + nbEtages
				+ ", hauteurEtage=" + hauteurEtage + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Immeuble other = (Immeuble) obj;
		if (couleur == null) {
			if (other.couleur != null)
				return false;
		} else if (!couleur.equals(other.couleur))
			return false;
		if (hauteurEtage != other.hauteurEtage)
			return false;
		if (nbEtages != other.nbEtages)
			return false;
		return true;
	}

	public Immeuble clone(){
		return (Immeuble) super.clone();
}
}
