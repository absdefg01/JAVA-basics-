
public class ObjetGraphique {
	private double coordX;
	private double coordY;
	
	public ObjetGraphique(double dx, double dy){
		this.coordX=dx;
		this.coordY=dy;
	}

	
	
	@Override
	public String toString() {
		return "ObjetGraphique [coordX=" + coordX + ", coordY=" + coordY + "]";
	}
	
	public void translater(double dx, double dy){
		this.coordX +=dx;
		this.coordY +=dy;
	}
	
	public ObjetGraphique clone(){
		ObjetGraphique o = null;
		try {
			o = (ObjetGraphique) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return o;
	}

}

