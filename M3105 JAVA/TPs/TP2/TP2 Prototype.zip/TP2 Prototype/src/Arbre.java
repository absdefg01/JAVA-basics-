
public class Arbre extends ObjetGraphique  implements Cloneable {
	private int hauteur;
	private String couleurTronc;
	private String couleurFeuilles;
	public Arbre(double x, double y, int h, String ct, String cf) {
		super(x, y);
		this.couleurFeuilles=cf;
		this.couleurTronc=ct;
		this.hauteur=h;
	}
	
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	public void setCouleurTronc(String couleurTronc) {
		this.couleurTronc = couleurTronc;
	}
	public void setCouleurFeuilles(String couleurFeuilles) {
		this.couleurFeuilles = couleurFeuilles;
	}
	
	@Override
	public String toString() {
		return "Arbre [hauteur=" + hauteur + ", couleurTronc=" + couleurTronc
				+ ", couleurFeuilles=" + couleurFeuilles + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Arbre other = (Arbre) obj;
		if (couleurFeuilles == null) {
			if (other.couleurFeuilles != null)
				return false;
		} else if (!couleurFeuilles.equals(other.couleurFeuilles))
			return false;
		if (couleurTronc == null) {
			if (other.couleurTronc != null)
				return false;
		} else if (!couleurTronc.equals(other.couleurTronc))
			return false;
		if (hauteur != other.hauteur)
			return false;
		return true;
	}
	
	public Arbre clone(){
			return (Arbre) super.clone();
	}

	
	}
	

