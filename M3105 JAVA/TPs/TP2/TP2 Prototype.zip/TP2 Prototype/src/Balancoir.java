
public class Balancoir extends ObjetGraphique implements Cloneable {
private String couleur;
private int hauteur;
private int nbSiege;
	public Balancoir(double x, double y, String c, int h, int nS) {
		super(x, y);
		this.couleur=c;
		this.hauteur=h;
		this.nbSiege=nS;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	public void setNbSiege(int nbSiege) {
		this.nbSiege = nbSiege;
	}
	@Override
	public String toString() {
		return "Balancoir [couleur=" + couleur + ", hauteur=" + hauteur
				+ ", nbSiege=" + nbSiege + "]";
	}
	public Balancoir clone(){
		return (Balancoir) super.clone();
}

}
