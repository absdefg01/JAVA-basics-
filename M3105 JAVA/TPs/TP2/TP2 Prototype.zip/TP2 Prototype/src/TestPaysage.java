
public class TestPaysage {
	public static void main(String[] args) {
		Paysage p = new Paysage();
		System.out.println(p.toString());
	}

}
