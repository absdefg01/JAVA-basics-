
public class Catalogue implements Cloneable {
	private Balancoir uneBlancoir = new Balancoir(1.0,1.0,"bleu",5,10);
	private Toboggan toboggan= new Toboggan(1.1, 2.0,"vert", 50, 30);
	private Banc banc = new Banc(2.4, 6.0, "blanc", 2,3);
	private Tourniquet tourniquet = new Tourniquet(2.5,4.6,"violet", 1,5.0);
    private Immeuble immeuble = new Immeuble (5.0, 5.0, "gris", 5, 9);
    private Arbre arbre = new Arbre (1.1,2.0,3,"rouge","blanc");
public Catalogue(){
	
}

public Balancoir getBalancoir() {
	return  this.uneBlancoir.clone();
}

public Toboggan getToboggan() {
	return  this.toboggan.clone();
}

public Banc getBanc() {
	return  this.banc.clone();
}

public Tourniquet getTourniquet() {
	return  this.tourniquet.clone();
}

public Arbre getArbre() {
	return  this.arbre.clone();
}

public Immeuble getImmeuble() {
	return this.immeuble.clone();
}

}
