
public class Banc extends ObjetGraphique implements Cloneable {
private String couleur;
private int hauteur;
private int largeur;
	public Banc(double x, double y, String c, int h, int l) {
		super(x, y);
		this.couleur=c;
		this.hauteur=h;
		this.largeur=l;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	public void setLargeur(int largeur) {
		this.largeur = largeur;
	}
	@Override
	public String toString() {
		return "Banc [couleur=" + couleur + ", hauteur=" + hauteur
				+ ", largeur=" + largeur + "]";
	}
	
	public Banc clone(){
		return (Banc) super.clone();
}
}
