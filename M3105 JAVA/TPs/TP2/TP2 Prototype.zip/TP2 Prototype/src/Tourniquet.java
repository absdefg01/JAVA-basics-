
public class Tourniquet extends ObjetGraphique implements Cloneable{
	private String couleur;
	private int hauteur;
	private double diametre;
	public Tourniquet(double x, double y, String c, int h, double d) {
		super(x, y);
		this.couleur = c;
		this.hauteur = h;
		this.diametre = d;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	public void setDiametre(double diametre) {
		this.diametre = diametre;
	}
	@Override
	public String toString() {
		return "Tourniquet [couleur=" + couleur + ", hauteur=" + hauteur
				+ ", diametre=" + diametre + "]";
	}
	
	
	public Tourniquet clone(){
		return (Tourniquet) super.clone();
}
	

}
