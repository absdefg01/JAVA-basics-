
public class Paysage {
private Catalogue c;
private Balancoir uneBalancoir;
private Banc unBanc;
private Tourniquet unTourniquet;
private Arbre arbre;
private Immeuble immenble;

public Paysage(){
	this.c = new Catalogue();
	this.uneBalancoir=c.getBalancoir();
	this.arbre = c.getArbre();
	this.immenble =c.getImmeuble();
	this.unBanc =c.getBanc();
	this.unTourniquet =c.getTourniquet();
}


public String toString() {
	return "Paysage [c=" + this.c + ", uneBalancoir=" + this.uneBalancoir + ", unBanc="
			+ this.unBanc + ", unTourniquet=" + this.unTourniquet + ", arbre=" + this.arbre
			+ ", immenble=" + this.immenble + "]";
}



}
