

public class Cite {
	
	private String nom;
	private Catalogue c;
	private Balancoir uneBalan�oires;
	private  Banc unBanc;
	private Banc unBanc2;
	private Banc unBanc3;
	private Toboggan unToboggan;
	private Tourniquet unTourniquet;
	private Arbre unArbre;
	private Arbre unArbre2;
	private Immeuble unImmeuble;
	private Immeuble unImmeuble2;
	
	
	public Cite()
	{
		this.c = new Catalogue() ;
		this.nom = "Labege";
		this.unBanc = c.getBanc();
		this.unBanc2 = c.getBanc();
		this.unBanc3 = c.getBanc();
		this.unBanc2.translater(120, 80);
		this.unBanc3.translater(300, 45);
		this.uneBalan�oires = c.getBalancoir();
		this.unToboggan = c.getToboggan();
		this.unTourniquet = c.getTourniquet();
		this.unArbre = c.getArbre();
		this.unArbre2 = c.getArbre();
		this.unArbre2.translater(150, 122);
		this.unImmeuble = c.getImmeuble();
		this.unImmeuble2 = c.getImmeuble();
		this.unImmeuble2.translater(1000, 200);
	}
	
	public Object clone() 
	{
		Cite o = null;
		try 
		{
			o = (Cite) super.clone();
			
			o.uneBalan�oires = (Balancoir) this.uneBalan�oires.clone();
			o.unBanc  =(Banc) this.unBanc.clone();
			o.unBanc2 = (Banc) this.unBanc2.clone();
			o.unBanc3 = (Banc) this.unBanc3.clone();
			o.unToboggan = (Toboggan) this.unToboggan.clone();
			o.unArbre = (Arbre) this.unArbre.clone();
			o.unArbre2 = (Arbre) this.unArbre2.clone();
			o.unImmeuble = (Immeuble) this.unImmeuble.clone();
		    o.unImmeuble2 = (Immeuble) this.unImmeuble2.clone();

		}
		catch(CloneNotSupportedException cnse)
		{
			cnse.printStackTrace(System.err);
		}
		
		return o;		
	}

	@Override
	public String toString() {
		return "La Cit� de nom : " + this.nom + " est compos� de :" + "uneBalan�oires "
				+ this.uneBalan�oires + ", unBanc=" + this.unBanc + ", unBanc2="
				+ this.unBanc2 + ", unBanc3=" + this.unBanc3 + ", unToboggan="
				+ this.unToboggan + ", unTourniquet=" + this.unTourniquet + ", unArbre="
				+ this.unArbre + ", unArbre2=" + this.unArbre2 + ", unImmeuble="
				+ this.unImmeuble + ", unImmeuble2=" + this.unImmeuble2 + "]";
	}
	
	
		
	}
	


