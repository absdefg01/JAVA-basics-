import static org.junit.Assert.*;


public class Test {

	@org.junit.Test
	public void test1() {
		Arbre a = new Arbre(1.1,2.0,3,"rouge","blanc");
		Arbre aa = (Arbre)a.clone();
		assertTrue(a.equals(aa));
		assertNotSame(a,a.clone());
	}
	@org.junit.Test
	public void test2() {
		
		Immeuble i = new Immeuble (5.0, 5.0, "gris", 5, 9);
		Immeuble i1 = (Immeuble) i.clone(); 
		assertTrue(i.equals(i1));
		assertNotSame(i,i.clone());
	}


}
