
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Cite c = new Cite();
		
		System.out.println(c);
	}

}
